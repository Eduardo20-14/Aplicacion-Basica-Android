package com.example.calculadora_e11;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

//Definimos Las Variables
public class MainActivity extends Activity {
	public double V1, V2;
	public EditText qV1, qV2;
	public TextView Resultado;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//Le damos valores 
		qV1 = (EditText) findViewById(R.id.editText1);
        qV2 = (EditText) findViewById(R.id.editText2);
        Resultado = (TextView) findViewById(R.id.textView1);
	}
	
	//Operaciones
	//Metodo para hacer la suma
	public void SUMAR(View view){
	     V1 = Double.parseDouble(qV1.getText().toString());
	     V2 = Double.parseDouble(qV2.getText().toString());
	     Resultado.setText(Double.toString(V1+V2));
  }
	//Metodo para hacer la RESTA
		public void RESTAR(View view){
		     V1 = Double.parseDouble(qV1.getText().toString());
		     V2 = Double.parseDouble(qV2.getText().toString());
		     Resultado.setText(Double.toString(V1-V2));
	  }
		//Metodo para hacer la MULTIPLICACION
		public void MULTIPLICAR(View view){
		     V1 = Double.parseDouble(qV1.getText().toString());
		     V2 = Double.parseDouble(qV2.getText().toString());
		     Resultado.setText(Double.toString(V1*V2));
	  }
		//Metodo para hacer la DIVISION
		public void DIVIDIR(View view){
		     V1 = Double.parseDouble(qV1.getText().toString());
		     V2 = Double.parseDouble(qV2.getText().toString());
		     Resultado.setText(Double.toString(V1/V2));
	  }

}
